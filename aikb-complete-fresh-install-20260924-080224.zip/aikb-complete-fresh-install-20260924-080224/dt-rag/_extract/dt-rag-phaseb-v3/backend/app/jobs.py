"""
In-process, ephemeral ingestion job tracker.

DELIBERATE DESIGN DECISION (see ARCHITECTURE_PHASE_B.md section G): Phase B
does not introduce a second database for job state. This dict is lost on
every rag-api restart. This is acceptable because Phase B does not perform
any autonomous/scheduled crawling -- /v1/ingestion/start is a manually
triggered, single-run operation for foundation testing only. If a caller
needs durability across a restart, that is a Phase C/E decision to wire
this up to AIKB's existing background_jobs table via an external_job_id
passthrough (already supported below), not something to solve here by
adding Postgres prematurely.
"""
import threading
import uuid
from datetime import datetime, timezone
from enum import Enum


class JobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


_jobs: dict[str, dict] = {}
_lock = threading.Lock()


def create_job(external_job_id: str | None = None) -> str:
    job_id = str(uuid.uuid4())
    with _lock:
        _jobs[job_id] = {
            "job_id": job_id,
            "external_job_id": external_job_id,
            "status": JobStatus.PENDING.value,
            "pages_crawled": 0,
            "documents_changed": 0,
            "documents_unchanged": 0,
            "documents_failed": 0,
            "error": None,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
    return job_id


def update_job(job_id: str, **fields):
    with _lock:
        if job_id in _jobs:
            _jobs[job_id].update(fields)
            _jobs[job_id]["updated_at"] = datetime.now(timezone.utc).isoformat()


def get_job(job_id: str) -> dict | None:
    with _lock:
        return dict(_jobs[job_id]) if job_id in _jobs else None


def job_count() -> int:
    with _lock:
        return len(_jobs)
